
# python standard libraries -------------------------------------------------------------------------------------------------------
import sys

# python third-party libraries ----------------------------------------------------------------------------------------------------
import numpy as np
import cv2





def rgb2yuv(r, g, b):
    
    COEF_R, COEF_B = 0.299, 0.114
    
    y = COEF_R * r + COEF_B * b + (1-COEF_R-COEF_B) * g
    u = 0.5/(1.0-COEF_B) * (b - y)
    v = 0.5/(1.0-COEF_R) * (r - y)
    
    y = (219.0/256.0)*y + 16.5
    u = (224.0/256.0)*u + 128.5
    v = (224.0/256.0)*v + 128.5
    
    return y, u, v





def read_yuv_frames_from_video_file(filename):
    
    video = cv2.VideoCapture(filename)
    
    Yframes = []
    Uframes = []
    Vframes = []
    
    for i_frame in range(1000000) :
        
        read_success, frame_rgb = video.read()
        
        if not read_success:
            break
    
        frame_rgb_float = np.array( frame_rgb , dtype = np.float64 )
        
        Y, U, V = rgb2yuv(frame_rgb_float[:,:,2], frame_rgb_float[:,:,1], frame_rgb_float[:,:,0])
        
        Yframes.append( np.array(Y, dtype=np.uint8) )
        Uframes.append( np.array(U, dtype=np.uint8) )
        Vframes.append( np.array(V, dtype=np.uint8) )
    
    Yframes = np.array( Yframes , dtype = np.uint8 )
    Uframes = np.array( Uframes , dtype = np.uint8 )
    Vframes = np.array( Vframes , dtype = np.uint8 )
    
    return Yframes, Uframes, Vframes






if __name__ == "__main__" :
    
    video_filename, raw_filename = None, None
    
    for arg in sys.argv[1:] :
        if video_filename is None :
            video_filename = arg
        else:
            raw_filename = arg
    
    if   video_filename is None  or  raw_filename is None :
        print('Usage :  python %s <input_video_file> <output_yuv_raw_file>' % sys.argv[0])
        exit(-1)
    
    print('reading %s ...' % (video_filename) )
    Yframes, Uframes, Vframes = read_yuv_frames_from_video_file(video_filename)
    
    nframes, h, w = Yframes.shape
    print('frame size: %dx%d ,    number of frames: %d' % (w, h, nframes))
    
    print('saving to %s ...' % (raw_filename) )
    with open(raw_filename, 'wb') as fp_out:
        for i in range(nframes):
            fp_out.write(Yframes[i].tobytes())
            fp_out.write(Uframes[i].tobytes())
            fp_out.write(Vframes[i].tobytes())




